/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/Bold/CurrencySymbols.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["STIXGeneral-bold"],{8355:[676,0,611,11,583],8356:[684,16,500,21,477],8359:[676,14,1369,16,1341],8364:[672,12,500,29,478]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/Bold/CurrencySymbols.js");

